import sys
sys.path.append('..')

from controller import controller

def createAccount():
    name = input('Enter your Username : ')
    email = input('Enter your Email ID : ')
    user = controller.createAcc(name,email)

'''
def balEnquiry()'''
