import sys

sys.path.append('..')

from Model import model

def createAcc(name,email):
    user = model.createAccount(name,email)
    return user

def balEnquiry(email,pin):
    res = model.enquiry(email,pin)
    return res

def authenticateUser(email,pin):
    auth , user = model.authenticate(email,pin)
    return auth , user

def withdraw(amount,user):
    msg = model.withdraw(amount, user)
    return msg