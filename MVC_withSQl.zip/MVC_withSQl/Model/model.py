import random
from Model import data_io

class Bank:
    def __init__(self,name,email):
        self.name = name
        self.email = email
        self.__acc_no = random.randint(99999,100000000)
        self.__pin = random.randint(1000,9999)
        self.__balance = 0

    @property
    def acc_no(self):
        print('Acc No Getter called for',self.name)
        return self.__acc_no

    @acc_no.setter
    def acc_no(self,value):
        self.__acc_no = value
        print('Setter called and acc no is set.')

    @property
    def Pin(self):
        return self.__pin

    @Pin.setter
    def Pin(self,value):
        self.__pin = value
        print('Setter called and the pin is set.')

    @property
    def bal(self):
        print('Bal Getter called for',self.name)
        return self.__balance

    @bal.setter
    def bal(self,value):
        self.__balance = value
        print('Setter called for and balance is set.')

    def __str__(self):
        return self.name

#users = []

def createAccount(name,email):
    obj = Bank(name,email)
    obj.acc_no = random.randint(99999,100000000)
    obj.pin = random.randint(1000,9999)
    obj.bal = 0
    data_io.createAccount(obj)
    # users.append(obj)
    return obj

def login(email,pin):
    users = data_io.readUsers()
    for i in range(len(users)):
        if users[i][1] == email and users[i][1] == pin:
            return users[i]

        else:
            return 'Invalid Details, User not found'


def enquiry(email,pin):
    res = login(email,pin)
    if isinstance(res,str):
        msg = res
    else:
        msg = "Hello {} , Your Balance is {}.".format(res[0],res[-1])

    return msg

def withdraw(amount,user):
    total_bal = int(user[-1])
    if total_bal < amount:
        msg = 'Insufficient Balance.'

    else:
        total_bal -= amount
        msg = 'Transaction Successful , Remaining balance is {}.'.format(total_bal)

    return msg

def authenticate(email,pin):
    res = login(email,pin)
    if isinstance(res,str):
        msg = res
    else:
        msg = 'Valid'

    return msg , res