import sys
sys.path.append('..')

from Controller import controller

def createAccount():
    name = input("Enter your name : ")
    email = input("Enter your email : ")
    user = controller.createAcc(name,email)
    print("Hello {}, Your Account Created Successfully".format(user))
    print("Your Account Number is",user.acc_no)
    print("Your PIN is",user.Pin)
    print("Your current balance is",user.bal)

def balEnquiry():
    email = input("Enter your email : ")
    pin = input("Enter your PIN : ")
    res = controller.balEnquiry(email,pin)
    print(res)


def withdraw():
    email = input("Enter your email : ")
    pin = input("Enter your PIN : ")
    res, user = controller.authenticateUser(email,pin)
    if res == 'Valid':
        amount = int(input('Welcome {} , Enter the amount you want to withdraw : '.format(user[0])))
        msg = controller.withdraw(amount,user)
        print(msg)
    else:
        print(res)

def finish():
    print('Thank You for banking with us.')



def menu():
    while True:
        print("""
        1. Create Account
        2. Balance Enquiry
        3. Withdraw
        4. Balance Transfer
        5. Deposit
        6. Quit
        """)
        ch = input("Enter your choice : ")
        if ch == '6':
            finish()
            break
        else:
            operations = {
                "1" : createAccount,
                "2" : balEnquiry,
                "3" : withdraw,
                # "4" : balTransfer,
                # "5" : deposit
            }
        operations.get(ch)()

menu()