HOST = 'localhost'
USERNAME = 'root'
DB_NAME = 'bankdb'
PORT = 3306

