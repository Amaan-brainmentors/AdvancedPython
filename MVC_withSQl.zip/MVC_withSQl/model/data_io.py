import pymysql
from model import config

try:
    connection = pymysql.connect(host = config.HOST,port = config.PORT ,
                                 database=config.DB_NAME,user=config.USERNAME,
                                 autocommit=True)
    cursor = connection.cursor()

except BaseException as ex:
    print('Connection Failed')

def createAccount(obj):
    query = "insert into customers values ('{}','{}',{},{},{})".format(obj.name,obj.email,obj.acc_no,obj.pin,obj.bal)

    cursor.execute(query)

def balEnquiry():
    # query = 'select * from customers where'
    pass