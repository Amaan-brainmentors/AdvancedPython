import random
from model import data_io

class Bank:
    def __init__(self,name,email):
        self.name = name
        self.email = email
        self.__accno = random.randint(99999,100000000)
        self.__pin = random.randint(1000,9999)
        self.__balance = 0

    @property
    def acc_no(self):
        print('Acc No Getter called for',self.name)
        return self.__accno

    @acc_no.setter
    def acc_no(self,value):
        self.__accno = value
        print('Setter called and acc no is set.')

    @property
    def Pin(self):
        return self.__pin

    @Pin.setter
    def Pin(self,value):
        self.__pin = value
        print('Setter called and the pin is set.')

    @property
    def bal(self):
        print('Bal Getter called for',self.name)
        return self.__balance
    @bal.setter
    def bal(self,value):
        self.__balance = value
        print('Setter called for and balance is set.')

    def __str__(self):
        return self.name

#users = []

def createAccount(name,email):
    obj = Bank(name,email)
    obj.acc_no = random.randint(99999,100000000)
    obj.pin = random.randint(1000,9999)
    obj.bal = 0
    date_io = createAccount(obj)
    # users.append(obj)
    return obj

def enquiry(email,pin):
    for i in range(len(users)):
        if users[i].email == email and users[i].getPin() == pin:
            return users[i]

        else:
            return "Invalid Details , User not Found"

