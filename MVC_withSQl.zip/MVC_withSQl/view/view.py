import sys
sys.path.append('..')

from controller import controller

def createAccount():
    name = input("Enter your name : ")
    email = input("Enter your email : ")
    user = controller.createAcc(name,email)
    print("Hello {}, Your Account Created Successfully".format(user))
    print("Your Account Number is",user.getAccountNumber())
    print("Your PIN is",user.getPin())
    print("Your current balance is",user.getBalance())

def balEnquiry():
    email = input("Enter your email : ")
    pin = input("Enter your PIN : ")
    res = controller.balEnquiry(email,pin)
    if isinstance(res, str):
        print(res)
    else:
        print("Hello {}, Your balance is {}",format(res.name,res.bal))

def finish():
    print('Thank You for banking with us.')



def menu():
    while True:
        print("""
        1. Create Account
        2. Balance Enquiry
        3. Withdraw
        4. Balance Transfer
        5. Deposit
        6. Quit
        """)
        ch = input("Enter your choice : ")
        if ch == '6':
            finish()
            break
        else:
            operations = {
                "1" : createAccount,
                "2" : balEnquiry,
                # "3" : withdraw,
                # "4" : balTransfer,
                # "5" : deposit

            }
        operations.get(ch)()

menu()