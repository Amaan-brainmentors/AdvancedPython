import threading

def job_1():
    print('Job 1 started')
    for i in range(10000):
        for j in range(10000):
            k = i + j
    print('Job 1 done')

def job_2():
    print('Job 2 started')
    for i in range(100):
        for j in range(10):
            k = i + j
    print('Job 2 done')


job_1()
job_2()
print('-'*60)

worker_1 = threading.Thread(target=job_1)
worker_2 = threading.Thread(target=job_2)


worker_1.start()
worker_2.start()

worker_1 = threading.Thread(target=job_1,name='Thread Unique')

worker_1.start()