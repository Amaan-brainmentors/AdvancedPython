import threading
import time

def job():
    print('Job started by {}'.format(threading.current_thread().getName()))
    time.sleep(2)           #dealy the program for 2 seconds
    for i in range(1000):
        for j in range(1000):
            k = i + j
    print('Job ended by {}'.format(threading.current_thread().getName()))

print(threading.current_thread().getName())

for i in range(5):
    t = threading.Thread(target=job, name='Thread_{}'.format(i))
    t.start()