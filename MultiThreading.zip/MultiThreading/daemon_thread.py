# garbage collection

import threading

def job_1():
    print('Job 1 started')
    for i in range(10000):
        for j in range(10000):
            k = i + j
    print('Job 1 done')

def job_2():
    print('Job 2 started')
    for i in range(100):
        for j in range(1000):
            k = i + j
    print('Job 2 done')



worker_1 = threading.Thread(target=job_1)
worker_2 = threading.Thread(target=job_2)

worker_1.setDaemon(True)

worker_1.start()
worker_2.start()