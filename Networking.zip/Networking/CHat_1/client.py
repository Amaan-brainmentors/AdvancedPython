import socket

s = socket.socket()
port = 9099

s.connect(('localhost', port))

msg = input('Enter you message : ')

while msg!= 'q':

    s.send(msg.encode())
    data = s.recv(1024).decode()
    print('Server :', data)
    msg = input('Enter you message(Client) : ')
s.close()

