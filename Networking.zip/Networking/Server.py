import socket

s = socket.socket()

port = 9990

s.bind(('localhost', port))
print('Socket binded to', port)

s.listen(5)
print('Socket is listening....')
msg = 'Thank YOU !'


while True:
    conn, address = s.accept()
    print('Got connection from', address)
    conn.send(msg.encode())
    conn.close()

