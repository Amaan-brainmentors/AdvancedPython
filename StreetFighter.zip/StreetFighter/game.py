import pygame
import random
pygame.init()

width = 1280
height = 720

screen = pygame.display.set_mode((width,height))

white = 255,255,255
red = 255,0,0
black = 0,0,0
color_1 = 128,184,160
RED = (255,0,0)
GREEN = (0,255,0)
YELLOW = (255,255,0)

clock = pygame.time.Clock()
FPS = 75
splash_bg = pygame.image.load("img/k.png")
background = pygame.image.load("img/background.jpg")

#spritesheet work
class Spritesheet():

    def __init__(self,file_name):
        pygame.sprite.Sprite.__init__(self)
        self.spritesheet = file_name

    def getImage(self,x,y,width,height):
        image = pygame.Surface((width,height))
        image.blit(self.spritesheet,(0,0),(x,y,width,height))
        image.set_colorkey(color_1)

        return image

class Player1(pygame.sprite.Sprite):
    idleFrame = []
    walkingFrame = []
    punchFrame = []
    kickFrame = []
    superPunch = []

    isAttack = False

    health = 450
    strength = 0

    def __init__(self):
        super.__init__()
        sprite = Spritesheet(player_1_Sprite)

        #image extraction

        #idle
        self.image = sprite.getImage(5,17,43,83)
        self.idleFrame.append(self.image)
        self.image = sprite.getImage(54,18,45,81)
        self.idleFrame.append(self.image)
        self.image = sprite.getImage(104,17,45,83)
        self.idleFrame.append(self.image)
        self.image = sprite.getImage(153,16,44,84)
        self.idleFrame.append(self.image)

        #walking
        self.image = sprite.getImage(204, 23, 45, 77)
        self.walkingFrame.append(self.image)
        self.image = sprite.getImage(251, 19, 45, 81)
        self.walkingFrame.append(self.image)
        self.image = sprite.getImage(300, 16, 45, 84)
        self.walkingFrame.append(self.image)
        self.image = sprite.getImage(350, 19, 45, 81)
        self.walkingFrame.append(self.image)
        self.image = sprite.getImage(401, 18, 43, 82)
        self.walkingFrame.append(self.image)

        #punch
        self.image = sprite.getImage(170, 133, 43, 83)
        self.punchFrame.append(self.image)
        self.image = sprite.getImage(218, 129, 51, 87)
        self.punchFrame.append(self.image)
        self.image = sprite.getImage(272, 130, 75, 86)
        self.punchFrame.append(self.image)
        self.image = sprite.getImage(218, 129, 51, 87)
        self.punchFrame.append(self.image)
        self.image = sprite.getImage(170, 133, 43, 83)
        self.punchFrame.append(self.image)

        #kick
        self.image = sprite.getImage(194, 263, 45, 85)
        self.kickFrame.append(self.image)
        self.image = sprite.getImage(243, 260, 59, 86)
        self.kickFrame.append(self.image)
        self.image = sprite.getImage(305, 261, 72, 86)
        self.kickFrame.append(self.image)
        self.image = sprite.getImage(379, 273, 62, 74)
        self.kickFrame.append(self.image)
        self.image = sprite.getImage(447, 272, 45, 75)
        self.kickFrame.append(self.image)

        #superpunch
        self.image = sprite.getImage(616, 531, 52, 83)
        self.superPunch.append(self.image)
        self.image = sprite.getImage(672, 537, 66, 77)
        self.superPunch.append(self.image)
        self.image = sprite.getImage(743, 542, 66, 73)
        self.superPunch.append(self.image)
        self.image = sprite.getImage(814, 543, 71, 72)
        self.superPunch.append(self.image)

        #hitbox
        self.rect = self.image.get_rect()
        self.rect.center = (width / 2 - 250, height / 2 + 70)
        self.moveX = 0

        self.pos = 0

        self.idle = True
        self.move = False
        self.punch = False
        self.kick = False
        self.spunch = False

    def update(self,*args):
        self.pos += 4
        self.hit = pygame.sprite.groupcollide(playerSprite1,playerSprite2,False,False)
        keystate = pygame.key.get_pressed()

        if keystate[pygame.K_d]:#right movement
            self.moveX = 5
            self.move = True
            self.idle = False
            if self.hit:
                self.moveX = 0
                self.move = False
                self.idle = True
        elif keystate[pygame.K_a]:
            self.moveX = -5
            self.move = True
            self.idle = False
            self.kick = False
            self.spunch = False
            if self.rect.x < 0:
                self.move = False
                self.moveX = 0
        elif keystate[pygame.K_w]:
            self.idle = False
            self.punch = True
        elif keystate[pygame.K_s]:
            self.idle = False
            self.kick = True
        elif keystate[pygame.K_s]:
            self.idle = False
            self.kick = False
            self.spunch = True
        else:
            self.idle = True
            self.move = False
            self.punch = False
            self.kick = False
            self.spunch = False
            self.moveX = 0

        if self.idle:
            self.currentFrame = (self.pos // 30) % len(self.idleFrame)
            self.image = self.idleFrame[self.currentFrame]
        elif self.move:
            self.currentFrame = (self.pos // 20) % len(self.walkingFrame)
            self.image = self.walkingFrame[self.currentFrame]
        elif self.punch:
            self.currentFrame = (self.pos // 30) % len(self.punchFrame)
            self.image = self.punchFrame[self.currentFrame]

            if self.hit:
                player2.strength -= 1
                player2.isAttack = True

        elif self.kick:
            self.currentFrame = (self.pos // 30) % len(self.kickFrame)
            self.image = self.kickFrame[self.currentFrame]
            if self.hit:
                player2.strength -= 2
                player2.isAttack = True

        elif self.spunch:
            self.currentFrame = (self.pos // 30) % len(self.superPunch)
            self.image = self.superPunch[self.currentFrame]
            if self.hit:
                player2.strength -= 3
                player2.isAttack = True

        self.rect.x += self.moveX
        img_w = self.image.get_width() * 3
        img_h = self.image.get_height() * 3
        self.image = pygame.transform.scale(self.image,(img_w, img_h))
        self.rect.width = img_w
        self.rect.height = img_h

player_1_Sprite = pygame.image.load("img/fighter_1.gif")

all_sprites = pygame.sprite.Group()
player1 = Player1()
playerSprite1 = pygame.sprite.Group()
playerSprite1.add(player1)
all_sprites.add(player1)



#Screen Display
def timer(seconds):
    font = pygame.font.Font('zorque.ttf', 40)
    seconds_display = font.render("Time Left: "+str(seconds),1,GREEN)
    screen.blit(seconds_display,(width/2-120,0))

def startScreen():
    font = pygame.font.Font('zorque.ttf',70)
    text_1 = font.render("HIT space to",True,RED)
    text_2 = font.render("Start the game",True,RED)
    screen.blit(text_1,(50,300))
    screen.blit(text_2,(80,400))


def gameOverScreen(x):
    font = pygame.font.Font('zorque.ttf', 70)
    text_1 = font.render("Game Over", True,white)
    text_2 = font.render("Player {} won.".format(x), True, white)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        screen.blit(text_1,(width/2-250,height/2-50))
        screen.blit(text_2, (width/2-250,height/2-150))
        pygame.display.update()

def main():
    seconds = 30
    running = True

    while running:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.USEREVENT + 1:
                seconds -= 1

        if seconds == -1:
            gameOverScreen(" ")


        screen.fill(white)
        screen.blit(background, (0, 0))
        timer(seconds)
        pygame.display.update()
        clock.tick(FPS)

def splashScreen():

    running = True

    while running:
        clock.tick(FPS)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:

                    main()

        screen.blit(splash_bg,(0,0))
        startScreen()
        pygame.display.flip()

if __name__=='__main__':
    splashScreen()