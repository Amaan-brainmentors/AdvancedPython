host = 'localhost'
port = 3306
database = 'bmpl'
user = 'root'