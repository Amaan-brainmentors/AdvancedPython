host = 'localhost'
port = 3306
database = 'bmplTest'
user = 'root'