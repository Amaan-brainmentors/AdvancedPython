import cgi
import model

form = cgi.FieldStorage()

id = form.getvalue('id')

if form.getvalue('test'):
    form_state = True
    subject = form.getvalue('sub')
    grade = form.getvalue('grade')
    model.insertTest(id,subject,grade)
else:
    form_state = False



print('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Test</title>
</head>
<body>
    <h1>Create Test</h1>
''')

if not form_state:
    print("""
        <form action="createTest.py">
        <input type="hidden" value={} name="id">
        <input type="hidden" value="create" name="test">
        <table>
            <tr>
                <td>Choose Subject</td>
                <td>
                    <select name="sub">
                        <option>Choose Subject</option>
                        <option value="Computer Science">Computer Science</option>
                        <option value="math">Math</option>
                        <option value="GK">General Knowledge</option>
                        <option value="python">Python</option>
                        <option value="Science">Science</option>
                    </select>
                </td>
            </tr>

            <tr>
                <td>Choose Grade</td>
                <td>
                    <select name="grade">
                        <option>Choose Grade</option>
                        <option value="8">8th</option>
                        <option value="9">9th</option>
                        <option value="10">10th</option>
                        <option value="11">11th</option>
                        <option value="12">12th</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value="Insert Question">
                </td>
            </tr>
        </table>
    </form>
    <hr>
    """.format(id))

print("""
</body>
</html>
""")