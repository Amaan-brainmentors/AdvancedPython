import cgi
import model

import cgi
import model

form = cgi.FieldStorage()
role = form.getvalue('role')
id = form.getvalue('u_id')
pwd = form.getvalue('u_pwd')

user = model.loginUser(role,id,pwd)
name = user[0][0]

print('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
    <h1>Login Successful</h1>
    <h2>Welcome {}</h2>
</body>
</html>
'''.format(name))