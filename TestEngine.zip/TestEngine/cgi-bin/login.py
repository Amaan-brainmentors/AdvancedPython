import cgi
import model

form = cgi.FieldStorage()
role = form.getvalue('role')
id = form.getvalue('u_id')
pwd = form.getvalue('u_pwd')

user = model.loginUser(role,id,pwd)
name = user[0][0]

all_test = model.fetchAllTest()

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Login Successful</h1>
    <h2>Welcome {}</h2>
""".format(name))

if role == "teacher":
    # Query String
    print("<a href='teachersLogin.py?id={}'>Go to Teachers Page</a>".format(id))
else:
    print("<a href='studentsLogin.py?id={}'>Go to Student Page</a>".format(id))

print("""
<h2>Test created by you : </h2>
<table width='100%' border=2 cellpadding=10>
    <tr>
        <th>Test ID</th>
        <th>Subject</th>
        <th>Grade</th>
        <th>Visit Test</th>
    </tr>
""")
for i in range(len(all_test)):
    print("""
        <tr>
            <td> {} </td>
            <td> {} </td>
            <td> {} </td>
            <td> Visit Test </td>
    """.format(all_test[i][0], all_test[i][2], all_test[i][3]))

print("</table>")

print("""
</body>
</html>
""")