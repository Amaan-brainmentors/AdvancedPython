import cgi
import model

import cgi
import model

form = cgi.FieldStorage()
role = form.getvalue('role')
id = form.getvalue('u_id')
pwd = form.getvalue('u_pwd')

user = model.loginUser(role,id,pwd)
name = user[0][0]

print('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>
    <h1>Login Successful</h1>
    <h2>Welcome {}</h2>
'''.format(name))

if role == "teacher":
    # Query String
    print("<a href='teachersLogin.py?id={}'>Go to Teachers Page</a>".format(id))
else:
    print("<a href='studentsLogin.py?id={}'>Go to Student Page</a>".format(id))

print('''

</body>
</html>
''')