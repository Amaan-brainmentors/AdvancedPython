import data_io

class User:
    def __init__(self, role, name, id, pwd, grade):
        self.name = name
        self.role = role
        self.id = id
        self.pwd = pwd
        self.grade = grade

def registerUser(role, name, id, pwd, grade):
    obj = User(role, name, id, pwd, grade)
    data_io.storeUser(obj)

def loginUser(role, id, pwd):
    user = data_io.loginUser(role, id, pwd)
    return user

def fetchAllTest():
    data = data_io.fetchAllTest()
    return data

def fetchMyTest(id):
    data = data_io.fetchMyTest(id)
    return data

def fetchQuestions(id):
    data = data_io.fetchQuestions(id)
    return data

def insertTest(id,subject,grade):
    test = data_io.insertTest(id,subject,grade)
    return test

def getTest(id):
    test = data_io.getTest(id)
    return test

def insertQues(test_id,ques,opt_1,opt_2,opt_3,opt_4,ans):
    data_io.insertQues(test_id,ques,opt_1,opt_2,opt_3,opt_4,ans)

def fetchStudentData(id):
    data = data_io.getStudentData(id)
    return data

def getSubjects(grade):
    sub = data_io.getSub(grade)
    return sub

def getTestInfo(grade, sub):
    data = data_io.getInfo(grade,sub)
    return data

def getQuestions(id):
    ques = data_io.getQues(id)
    return ques