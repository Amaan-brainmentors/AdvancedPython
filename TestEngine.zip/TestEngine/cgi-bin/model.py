import data_io

class User:
    def __init__(self,role,name,id,pwd,grade):
        self.name = name
        self.role = role
        self.id = id
        self.pwd = pwd
        self.grade = grade



def registerUser(role,name,id,pwd,grade):
    obj = User(role,name,id,pwd,grade)
    data_io.storeUser(obj)

def loginUser(role,id,pwd):
    user = data_io.loginUser(role,id,pwd)
    return user