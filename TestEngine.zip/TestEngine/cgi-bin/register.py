import cgi
import model

form = cgi.FieldStorage()
role = form.getvalue('role')
name = form.getvalue('u_name')
id = form.getvalue('u_id')
pwd = form.getvalue('u_pwd')
grade = form.getvalue('grade')

model.registerUser(role,name,id,pwd,grade)

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Registration Successful</h1>
    <h2>Welcome {}</h2>
""".format(name))

if role == "teacher":
    # Query String
    print("<a href='teachersLogin.py?id={}'>Go to Teachers Page</a>".format(id))
else:
    print("<a href='studentsLogin.py?id={}'>Go to Student Page</a>".format(id))

print("""
</body>
</html>
""")