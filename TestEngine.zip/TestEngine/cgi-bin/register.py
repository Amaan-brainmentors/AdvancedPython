import cgi
import model

form = cgi.FieldStorage()
role = form.getvalue('role')
name = form.getvalue('u_name')
id = form.getvalue('u_id')
pwd = form.getvalue('u_pwd')
grade = form.getvalue('grade')

model.registerUser(role,name,id,pwd,grade)

print('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
</head>
<body>
    <h1>Registration Successful</h1>
    <h2>Welcome {}</h2>
</body>
</html>
'''.format(name))