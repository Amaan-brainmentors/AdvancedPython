import cgi
import model

form = cgi.FieldStorage()

grade = form.getvalue('grade')
sub = form.getvalue('sub')
test = model.getTestInfo(grade,sub)

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Start Test</h1>
    <hr>
""")

if len(test)==0:
    print("<h2>No Test Available for you.</h2>")
else:
    print("""
    <h2>Test Available : </h2>
    <table width='100%' border=2 cellpadding=10>
        <tr>
            <th>Test ID</th>
            <th>Subject</th>
            <th>Grade</th>
            <th>Start Test</th>
        </tr>
    """)

    for i in range(len(test)):
        print("""
        <tr>
                <td> {} </td>
                <td> {} </td>
                <td> {} </td>
                <td> <a href='startTest.py?t_id={}'>Start Test</a> </td>
        </tr>
        """.format(test[i][0], test[i][1], test[i][2], test[i][0]))

    print("</table>")


print("""
</body>
</html>
""")