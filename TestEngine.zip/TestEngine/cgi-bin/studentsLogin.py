import cgi
import model

form = cgi.FieldStorage()

id = form.getvalue('id')
my_data = model.fetchStudentData(id)

print('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Login</title>
</head>
<body>
    <h1>Student's Dashboard</h1>
    <h4>Name : {}</h4>
    <h4>Grade : {}</h4>

    <nav>
        <ul>
            <li> <a href = 'giveTest.py?id={}&grade={}'>Give Test</a> </li>
            <li> <a href = 'viewTest.py'>View Test</a> </li>
            <li> <a href = 'viewResults.py'>View Test Results</a> </li>
        </ul>
    </nav>
    <hr>
'''.format(my_data[0][0],my_data[0][3],id,my_data[0][3]))

print("""
</body>
</html>
""")