import cgi
import model

form = cgi.FieldStorage()

id = form.getvalue('id')
my_test = model.fetchMyTest(id)

print('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Teacher Login</title>
</head>
<body>
    <h1>Teacher's Dashboard</h1>

    <nav>
        <ul>
            <li> <a href = 'createTest.py?id={}'>Create Test</a> </li>
            <li> <a href = 'viewTest.py'>View Test</a> </li>
            <li> <a href = 'editTest.py'>Edit Test</a> </li>
            <li> <a href = 'deleteTest.py'>Delete Test</a> </li>
            <li> <a href = 'viewResults.py'>View Test Results</a> </li>
        </ul>
    </nav>
    <hr>
'''.format(id))

print("""
</body>
</html>
""")