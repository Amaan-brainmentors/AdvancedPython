import cgi
import model

form = cgi.FieldStorage()

id = form.getvalue('id')
my_test = model.fetchMyTest(id)

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Teacher's Dashboard</h1>
    <nav>
        <ul>
            <li> <a href='createTest.py?id={}'>Create Test</a> </li>
            <li> <a href='view_test.py'>View Test</a> </li>
            <li> <a href='editTest.py'>Edit Test</a> </li>
            <li> <a href='deleteTest.py'>Delete Test</a> </li>
            <li> <a href='viewResults.py'>View Results</a> </li>
        </ul>
    </nav>
    <hr>
""".format(id))

print("""
<h2>Test created by you : </h2>
<table width='100%' border=2 cellpadding=10>
    <tr>
        <th>Test ID</th>
        <th>Subject</th>
        <th>Grade</th>
        <th>Visit Test</th>
""")

for i in range(len(my_test)):
    print("""
        <tr>
            <td> {} </td>
            <td> {} </td>
            <td> {} </td>
            <td> <a href='view_test.py?t_id={}'>Visit Test</a> </td>
    """.format(my_test[i][0], my_test[i][2], my_test[i][3], my_test[i][0]))

print("</table>")

print("""
</body>
</html>
""")