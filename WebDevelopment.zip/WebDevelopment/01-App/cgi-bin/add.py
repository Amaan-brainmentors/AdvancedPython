a = 12
b = 24
c = a+b

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MyPage</title>
</head>
<body>

    <h1>Hello World using Python Programming</h1>
    <h2>Sum of {} and {} is {}.</h2>

</body>
</html>
""".format(a,b,c))