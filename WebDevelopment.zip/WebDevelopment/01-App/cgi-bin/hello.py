print('''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MyPage</title>
</head>
<body>
    <h1>Hello World Using Python Programming</h1>
    
</body>
</html>
''')