import cgi

form = cgi.FieldStorage()

a = int(form.getvalue('f_num'))
b = int(form.getvalue('s_num'))

c = a+b

