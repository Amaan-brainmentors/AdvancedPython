import cgi

form = cgi.FieldStorage()

a = int(form.getvalue('f_num'))
b = int(form.getvalue('s_num'))

c = a + b
d = a-b
e = a/b
f = a*b

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Python Programming</h1>
    <h2>Sum of {} and {} is {}.</h2>
    <h2>Sub of {} and {} is {}.</h2>
    <h2>Div of {} and {} is {}.</h2>
    <h2>Mul of {} and {} is {}.</h2>

</body>
</html>
""".format(a,b,c,a,b,d,a,b,e,a,b,f))

