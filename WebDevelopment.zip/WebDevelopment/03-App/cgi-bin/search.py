import json
import urllib.request as url
import cgi

form = cgi.FieldStorage()

city_name = form.getvalue('name')
API_KEY = ''
# https://openweathermap.org/api
# print(city_name)

req = url.urlopen(
    f'https://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={API_KEY}')
data = json.load(req)
weather = data['weather'][0]
print(data.keys())
print(weather.keys())
main = weather['main']
desc = weather['description']

print("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

    <h1>Current Weather</h1>

</body>
</html>
""")
